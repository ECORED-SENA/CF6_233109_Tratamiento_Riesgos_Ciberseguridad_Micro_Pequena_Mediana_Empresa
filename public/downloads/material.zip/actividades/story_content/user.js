function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5txH412U7nI":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

